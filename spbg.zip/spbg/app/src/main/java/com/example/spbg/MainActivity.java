package com.example.spbg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int your_ships[];
    private int opponent_ships[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void placeShipsRandomly(){ //hard coded for now, need to find a way to simplify
        Random random = new Random();
        for (int i = 1; i<=4; i++){
            int x = random.nextInt(9) + 1;
            int y = random.nextInt(9) + 1;
            boolean isHorizontal = random.nextBoolean();
//            if canPlaceShip(Ship ship, int x, int y, boolean isHorizontal) placeShip(Ship ship, int x, int y, boolean isHorizontal)
        }
        for (int i = 1; i<=3; i++){
            int x = random.nextInt(9) + 1;
            int y = random.nextInt(9) + 1;
            boolean isHorizontal = random.nextBoolean();
//            if CanPlaceShip()
        }
        for (int i = 1; i<=2; i++){
            int x = random.nextInt(9) + 1;
            int y = random.nextInt(9) + 1;
            boolean isHorizontal = random.nextBoolean();
//            if CanPlaceShip()
        }
            int x = random.nextInt(9) + 1;
            int y = random.nextInt(9) + 1;
            boolean isHorizontal = random.nextBoolean();
//            if CanPlaceShip()

    }
}
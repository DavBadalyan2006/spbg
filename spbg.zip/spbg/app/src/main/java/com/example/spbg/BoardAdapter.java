package com.example.spbg;

public class BoardAdapter{
//copy
}